from django.contrib import admin

from opportunity.models import Opportunity

admin.site.register(Opportunity)
