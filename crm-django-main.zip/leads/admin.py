from django.contrib import admin

from leads.models import Lead

admin.site.register(Lead)
